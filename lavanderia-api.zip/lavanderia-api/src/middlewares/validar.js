const { ErrorHttp } = require('./errores');

const ENTERO_MAXIMO = 2147483647;

const esObjetoPlano = (x) => x !== null && typeof x === 'object' && !Array.isArray(x);

// Un campo ausente es error si es requerido; si no, toma su valor por defecto o null.
function ausente(regla) {
  if (regla.requerido) return { error: 'Es obligatorio' };
  return { valor: regla.defecto !== undefined ? regla.defecto : null };
}

function evaluarTexto(valor, regla) {
  if (typeof valor !== 'string') return { error: 'Debe ser texto' };
  let texto = regla.sinRecortar ? valor : valor.trim();
  if (texto === '') return ausente(regla);
  if (regla.minusculas) texto = texto.toLowerCase();

  const min = regla.min ?? 1;
  const max = regla.max;
  if (texto.length < min || (max !== undefined && texto.length > max)) {
    if (max === undefined) return { error: `Debe tener al menos ${min} caracteres` };
    if (min <= 1) return { error: `Debe tener como máximo ${max} caracteres` };
    return { error: `Debe tener entre ${min} y ${max} caracteres` };
  }
  if (regla.patron && !regla.patron.test(texto)) {
    return { error: regla.mensajePatron || 'Tiene un formato inválido' };
  }
  if (regla.personalizada) {
    const mensaje = regla.personalizada(texto);
    if (mensaje) return { error: mensaje };
  }
  return { valor: texto };
}

function evaluarEntero(valor, regla, desdeConsulta) {
  const min = regla.min ?? 1;
  const max = regla.max ?? ENTERO_MAXIMO;
  const mensaje = regla.max === undefined
    ? 'Debe ser un número entero positivo'
    : `Debe ser un número entero entre ${min} y ${max}`;

  let numero;
  if (desdeConsulta) {
    if (typeof valor !== 'string' || !/^\d{1,10}$/.test(valor)) return { error: mensaje };
    numero = Number(valor);
  } else {
    if (typeof valor !== 'number' || !Number.isSafeInteger(valor)) return { error: mensaje };
    numero = valor;
  }
  if (numero < min || numero > max) return { error: mensaje };
  return { valor: numero };
}

function evaluarNumero(valor, regla) {
  if (typeof valor !== 'number' || !Number.isFinite(valor)) return { error: 'Debe ser un número' };
  if (regla.mayorQue !== undefined && valor <= regla.mayorQue) {
    return { error: `Debe ser mayor que ${regla.mayorQue}` };
  }
  if (regla.max !== undefined && valor > regla.max) {
    return { error: `No puede ser mayor que ${regla.max}` };
  }
  if (regla.decimales !== undefined) {
    const factor = 10 ** regla.decimales;
    if (Math.abs(valor * factor - Math.round(valor * factor)) > 1e-6) {
      return { error: `Admite como máximo ${regla.decimales} decimales` };
    }
  }
  return { valor };
}

function evaluarEnum(valor, regla) {
  if (typeof valor !== 'string' || !regla.valores.includes(valor)) {
    return { error: `Debe ser uno de: ${regla.valores.join(', ')}` };
  }
  return { valor };
}

function evaluar(valor, regla, desdeConsulta) {
  if (valor === undefined || valor === null) return ausente(regla);
  if (desdeConsulta) {
    // En la URL cada parámetro es un texto único (ni repetido ni anidado)
    if (typeof valor !== 'string') return { error: 'Debe enviarse una sola vez' };
    if (valor === '' && regla.tipo !== 'texto') return { error: 'No puede estar vacío' };
  }
  switch (regla.tipo) {
    case 'texto': return evaluarTexto(valor, regla);
    case 'entero': return evaluarEntero(valor, regla, desdeConsulta);
    case 'numero': return evaluarNumero(valor, regla);
    case 'enum': return evaluarEnum(valor, regla);
    default: throw new Error(`Tipo de regla desconocido: ${regla.tipo}`);
  }
}

// Recorre TODAS las reglas y copia solo los campos permitidos (evita asignación masiva).
function aplicarReglas(origen, reglas, desdeConsulta) {
  const datos = {};
  const detalles = [];
  for (const [campo, regla] of Object.entries(reglas)) {
    const resultado = evaluar(origen[campo], regla, desdeConsulta);
    if (resultado.error) detalles.push({ campo, mensaje: resultado.error });
    else datos[campo] = resultado.valor;
  }
  return { datos, detalles };
}

function lanzarInvalido(detalles) {
  throw new ErrorHttp(400, 'Datos inválidos', detalles);
}

// Cuerpo JSON -> req.datos
const validarCuerpo = (reglas) => (req, res, next) => {
  if (!esObjetoPlano(req.body)) {
    lanzarInvalido([{ campo: 'cuerpo', mensaje: 'Debe enviarse un objeto JSON' }]);
  }
  const { datos, detalles } = aplicarReglas(req.body, reglas, false);
  if (detalles.length) lanzarInvalido(detalles);
  req.datos = datos;
  next();
};

// Parámetros de consulta (?pagina=1&limite=10...) -> req.filtros
const validarQuery = (reglas) => (req, res, next) => {
  const { datos, detalles } = aplicarReglas(req.query, reglas, true);
  if (detalles.length) lanzarInvalido(detalles);
  req.filtros = datos;
  next();
};

// :id debe ser un entero positivo (si no, 400, nunca 404 ni 500)
function validarId(req, res, next) {
  const { id } = req.params;
  if (!/^[1-9]\d{0,9}$/.test(id) || Number(id) > ENTERO_MAXIMO) {
    lanzarInvalido([{ campo: 'id', mensaje: 'Debe ser un número entero positivo' }]);
  }
  next();
}

module.exports = { validarCuerpo, validarQuery, validarId, aplicarReglas };

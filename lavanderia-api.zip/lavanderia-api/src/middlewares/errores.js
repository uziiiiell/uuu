// Error con código HTTP; el mensaje se puede mostrar a un usuario final.
class ErrorHttp extends Error {
  constructor(status, mensaje, detalles) {
    super(mensaje);
    this.status = status;
    this.detalles = detalles;
  }
}

// 404 para cualquier ruta no definida
function rutaNoEncontrada(req, res) {
  res.status(404).json({ error: 'Ruta no encontrada' });
}

// Manejador central: traduce errores conocidos y oculta el resto (RNF-07)
function manejadorErrores(err, req, res, next) {
  if (res.headersSent) return next(err);

  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'JSON mal formado' });
  }
  if (err.type === 'entity.too.large') {
    return res.status(400).json({ error: 'El cuerpo de la petición es demasiado grande' });
  }
  if (err instanceof ErrorHttp) {
    const cuerpo = { error: err.message };
    if (err.detalles) cuerpo.detalles = err.detalles;
    return res.status(err.status).json(cuerpo);
  }
  if (err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({ error: 'El registro ya existe' });
  }
  if (err.code === 'ER_ROW_IS_REFERENCED_2') {
    return res.status(409).json({ error: 'No se puede eliminar: tiene registros asociados' });
  }
  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    return res.status(400).json({ error: 'Hace referencia a un registro que no existe' });
  }
  // Otros errores del lector de cuerpos (codificación no soportada, etc.)
  if (err.type && err.status >= 400 && err.status < 500) {
    return res.status(400).json({ error: 'Petición inválida' });
  }

  console.error(err);
  res.status(500).json({ error: 'Error interno del servidor' });
}

module.exports = { ErrorHttp, rutaNoEncontrada, manejadorErrores };

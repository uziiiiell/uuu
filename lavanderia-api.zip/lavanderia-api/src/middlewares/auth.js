const jwt = require('jsonwebtoken');

// ¿Quién eres? Falla -> 401
function auth(req, res, next) {
  const [tipo, token] = (req.get('authorization') || '').split(' ');
  if (tipo !== 'Bearer' || !token) {
    return res.status(401).json({ error: 'Token ausente' });
  }
  try {
    const carga = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
    if (!Number.isInteger(carga.id) || typeof carga.rol !== 'string') {
      return res.status(401).json({ error: 'Token inválido o vencido' });
    }
    req.usuario = { id: carga.id, rol: carga.rol };
    next();
  } catch {
    res.status(401).json({ error: 'Token inválido o vencido' });
  }
}

// ¿Qué puedes hacer? Falla -> 403
const permitir = (...roles) => (req, res, next) =>
  roles.includes(req.usuario.rol)
    ? next()
    : res.status(403).json({ error: 'No tiene permiso para esta acción' });

module.exports = { auth, permitir };
